package org.koushik.javabrains;

import java.io.*;
import java.sql.*;

public class TestData {

	private Connection con;
	private ResultSet resultSet;
	private Statement statement;
	public TestData(){
		con=null;
		statement=null;
		resultSet=null;
		try{
			Class.forName("org.sqlite.JDBC");
			con = DriverManager.getConnection("jdbc:sqlite:C:/Users/Zach/Desktop/Eclipse mars ee/Databases/test.db");
			statement = con.createStatement();
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	// Creates a new account with the information provided if the username or email isn't already in the database.
	public boolean newUser(String username, String password, int uType, String fName, String lName, String email){
		try{
			resultSet = statement.executeQuery("select uid from User where username='"+username+"' or email='"+email+"'");
			if(!resultSet.next())
				return false;
			resultSet = statement.executeQuery("select count(Uid) from User");
			resultSet.next();
			int userNumber = resultSet.getInt(1);
			statement.executeUpdate("insert into User values("+userNumber+",'"+username+"','"+password+"',"+uType+",'"+fName+"','"+lName+"','"+email+"')");
		} catch (Exception e){
			e.printStackTrace();
		}
		return false;
		
	}
	
	// Give the function the username and password and it returns the FirstName|LastName|Email if the login was successful
	public String login(String name, String password){
		String result = "";
		try{
			resultSet = statement.executeQuery("select fName, lName,email from User where username='"+name+"' and password='"+password+"'");
			result = "";
			while (resultSet.next()){
				result +=("Name: "+ resultSet.getString(1)+" "+resultSet.getString(2)+"\n");
			}
		} catch (SQLException e1){
			System.out.println("SQL Exception.");
			e1.printStackTrace();
		} catch (Exception e2){
			System.out.println("I hope this doesn't happen");
			e2.printStackTrace();
		}
		return result;
	}
	// Give the function the month and day and it returns all the events in the format Name|StartTime|EndTime|Description
	public String getEvents(int month, int day){
		String result = "";
		try{
			resultSet = statement.executeQuery("select Name, StartTime, EndTime, Description from Calendar where Day="+day+" and Month="+month);
			while (resultSet.next()){
				result +=(resultSet.getString(1)+"|"+resultSet.getString(2)+"|"+resultSet.getString(3)+"|"+resultSet.getString(4)+"\n");
			}
		} catch (SQLException e1){
			System.out.println("SQL Exception.");
			e1.printStackTrace();
		} catch (Exception e2){
			System.out.println("I hope this doesn't happen");
			e2.printStackTrace();
		}
		return result;
	}
	// "Month|Day|Name|StartTime|EndTime|Description"
	public void setEvent(String info){
		System.out.println(info);
		int month = Integer.parseInt(info.substring(0, info.indexOf("|")));
		info = info.substring(info.indexOf("|")+1);
		System.out.println(info);
		int day = Integer.parseInt(info.substring(0,info.indexOf("|")));
		info = info.substring(info.indexOf("|")+1);
		System.out.println(info);
		String name = info.substring(0,info.indexOf("|"));
		info = info.substring(info.indexOf("|")+1);
		System.out.println(info);
		String startTime = info.substring(0, info.indexOf("|"));
		info = info.substring(info.indexOf("|")+1);
		System.out.println(info);
		String endTime = info.substring(0, info.indexOf("|"));
		info = info.substring(info.indexOf("|")+1);
		System.out.println(info);
		String description = info;
		try{
			statement.executeUpdate("insert into Calendar values("+month+","+day+",'"+name+"','"+startTime+"','"+endTime+"','"+description+"')");
			
		} catch (SQLException e1){
			System.out.println("SQL Exception.");
			e1.printStackTrace();
		} catch (Exception e2){
			System.out.println("I hope this doesn't happen");
			e2.printStackTrace();
		}
	}
	
	public String getBulletin(){
		String bulletin = "";
		try {
			FileReader in = new FileReader("C:/Users/Zach/Desktop/Eclipse mars ee/Databases/bulletin.txt");
			BufferedReader reader = new BufferedReader(in);
			String tmp = reader.readLine();
			while(tmp!=null){
				bulletin += tmp;
				bulletin+="\n";
				tmp = reader.readLine();
			}
			reader.close();
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bulletin;
	}
	
	public void setBulletin(String bulletin){
		try{
			FileWriter out = new FileWriter("C:/Users/Zach/Desktop/Eclipse mars ee/Databases/bulletin.txt");
			BufferedWriter writer = new BufferedWriter(out);
			writer.write(bulletin);
			writer.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void close(){
		try {
			if(con!=null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
